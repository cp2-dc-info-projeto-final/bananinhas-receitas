# Entrevista com a Stakeholder Thamyres Leocadio Vilela

<h2> Primeira Pergunta </h2>

Thaynan Leocadio: Oi! Você já se encontrou em uma situação onde não sabia o que fazer. Diversos ingredientes mas nenhuma ideia? O nosso site conseguiria proporcionar a você um norte, uma receita perfeita com tudo aquilo que você possui em sua casa.
O quanto isso facilitaria  a sua vida?
<h2> Resposta </h2>

Thamyres Leocadio: Oi, boa noite! Nossa... eu achei muito legal a ideia desse site porque teríamos a capacidade de poder criar novas receitas com tudo que a gente tem em casa, sabe!? As vezes a gente tem todos os ingredientes, mas só que não vem ideias porque por exemplo as vezes eu tenho o arroz, tenho o frango, mas eu não quero fazer um risoto eu quero fazer um outro tipo de receita. E se eu puder colocar tudo que eu tenho que aparecem ideias de cardápios diferenciados, diversificados para que eu possa fazer vários tipos de comidas a gente nunca vai enjooar do que temos em casa, entendeu!? Também não vai precisar sair no meio de um dia corrido para pode passar no mercado e tal... a gente já consegue se virar com o que a gente tem de maneira bem bacana e bem legal podendo fugir daquele trivial, sabe!? "arroz, feijão e bife". A gente coloca o que a gente tem de ingredientes e eu acho assim, é muito legal legal mesmo! Independente de almoço, jantar, café da manhã... sabe!? Ideias que a gente possa variar o cardápio ela deixa sempre uma refeição saudável, alegre...

<h2> Segunda Pergunta </h2>

Thaynan Leocadio: Legal saber que você gostou da ideia, o site também terá uma função em que ele indica qual ingrediente está faltando na sua receita e caso possível a disponibilidade do produto ele apresentará um leque de opções em diversos supermercados. Como você decide o que cozinhar normalmente(?) e gostaria de saber se você tenta sempre mudar alguma coisa na receita para ver no que dá.

<h1> Resposta </h1>

Thamyres Leocadio: Sim, sim achei a ideia bem bacana mesmo, sabe!? E assim, a gente poder ter opções para a gente mudar caso a gente não tenha o ingrediente específico a gente poder ter acesso a outros ingredientes que não é o que a gente tem em casa é muito legal, sabe!? Algum tempero que a gente possa substituir por algum que a gente já tem isso é bem bacana! E outra coisa assim, então eu geralmente decido as coisas que irei cozinhar dependendo dos dias da semana porque como eu trabalho fora e tal... estudo... eu preciso me programar desde o início da semana para saber quais receitas eu vou fazer. Geralmente eu busco fazer variações para não levar sempre a mesma marmita, sabe!? Porque como sempre faço a janta que dê para a marmita do dia seguinte, para o almoço, eu sempre busco fazer comidas que sejam agradáveis, sabe!? Para que a gente não possa enjoar fácil, sabe!? Eu tento buscar várias ideias com os ingredientes que eu já tenho e tal... mas as vezes é assim... as vezes a gente fica meio enjoado, sabe!? De fazer a mesma comidas. Tento pensar mas as vezes me falta ideia e tempo, tendo esse site que eu possa me inspirar em coisas novas e saber o que eu poderia substituir facilitaria bastante a minha vida.

<h2> Terceira Pergunta </h2>

Thaynan Leocadio: Qual a frequência em que você utiliza sites como ["Tudogostoso"](https://www.tudogostoso.com.br/) e o ["Tastemade"](https://www.tastemade.com.br/)? Esses sites são referência no brasil no quesito receita, há alguma fórmula secreta acerca de tanto sucesso?

<h2> Resposta </h2>

Thamyres Leocadio: Então, eu uso esses sites, principalmente o site ["Tudogostoso"](https://www.tudogostoso.com.br/) com bastante frequência, acho que... pelo menos uma vez por semana eu dou uma olhadinha em receitas que as vezes até algumas coisas que são bem simples eu gosto de olhar porque dicas nunca são demais e a gente consegue seguir um padrão de cozimento e tal... de tempo de preparo, isso é bem legal! Eu acho que o segredo para o sucesso desses sites é a maneira direta que eles agem, não ficam enrolando e tal... dizem os ingredientes, explicam a receita e pronto! Não fica aquela enrolação de muito texto, muita coisas escritas e são bem diretos. Eu acho que esse é o segredo do sucesso deles.

<h2> Quarta Pergunta </h2>

Thaynan Leocadio: Principalmente o TasteMade possui milhões de seguidores nas redes sociais, é uma vantagem no cenário atual do país investir e manter uma rede social ativa?

<h2> Resposta </h2>

Thamyres Leocadio: Sim, sem dúvidas! É muito importante investir, porque cada vez mais a população tem mais acesso a comunicação por redes sociais, entendeu!? Então a internet está cada dia crescendo mais e cada dia mais gente tem mais acesso a comunicação e a informação pela internet por redes sociais, como facebook, instagram... essas redes nos dão mais fácil acesso às receitas porque podemos ver vídeos de como as coisas são feitas e podemos ter uma ideia do resultado final.

<h2> Conclusão </h2>
 Então galera, é isso.  Decidi fazer uma entrevista rápida para que a análise da mesma seja feita da melhor forma possível. Valeu!!!
