# Bananinhas receitas

## Alunos:
- Matheus Pereira da Silva<br>
- Felipe Siqueira<br>
- Thaynan Vilela<br>
- Uilson Gabriel<br>

## Navegação

### [Proposta](https://github.com/cp2-dc-info-projeto-final/bananinhas-receitas/blob/master/Modelo/Proposta.md)

### [Entrevista](https://github.com/cp2-dc-info-projeto-final/bananinhas-receitas/blob/master/Modelo/Entrevista.md)

### [Audio da Entrevista](https://github.com/cp2-dc-info-projeto-final/bananinhas-receitas/tree/master/Modelo/AudioEntrevista)

### [Requisitos](https://github.com/cp2-dc-info-projeto-final/bananinhas-receitas/blob/master/Modelo/Requisitos.md)
