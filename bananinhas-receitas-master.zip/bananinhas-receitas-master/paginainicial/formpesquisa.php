<form method="post" action="pesquisa.php">
    pesquisar:<input type="text" name="pesquisar">
    <input type="submit" value="buscar">
</form>